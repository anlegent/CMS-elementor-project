<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '/%@(U3XUf $1oma2G2Jn58C>0fT8v?NClG#iXb%QfPr[zNM0E^zOwjWry9MdwF@/' );
define( 'SECURE_AUTH_KEY',   'o(E;SeN` }6!cik.bVMWRfM^jJ@0a|VyX.Ls%T9^=}_E>x<A+>jD8{ggYLO$*+W^' );
define( 'LOGGED_IN_KEY',     '=JcqO-)I-n8B-+697}~4=|zO:Cl9)ZA LU<3:SU6CY{Le.RxqdF=`qMq9#d#e=R:' );
define( 'NONCE_KEY',         'fUt8W:^qC9E62ERC^5K >.h}+uBu^,oWQm PMYoE#bH1Q_Itgbw9Sr169kQ(4})y' );
define( 'AUTH_SALT',         ' gR_7w&F2PFB$6n>aa):-F)n{9:^D}aYn)X+1tWF1hq~2B!wlmsro*A*&6<##8>/' );
define( 'SECURE_AUTH_SALT',  'hW&k/GcS7B`2d}2bXDL!i9gq]exB+SZW9fEIGL{.>S#IPE$t6gBEEov_(HbKxM05' );
define( 'LOGGED_IN_SALT',    'ljHKZeuGzy~UIkQ?C^QhSz^b^DM4V*/LX Wb0Tdf(+C4:rr[bS2.2%irvMgH2xX/' );
define( 'NONCE_SALT',        '{^Blek?YyACXqKVe-+DEjyqt{L+HY@V[^RiaDT?T-g9Bz0~R[3%Bhnt8CEhTas%s' );
define( 'WP_CACHE_KEY_SALT', 'IA{.*0QLOY1?>|}sLMtE-7@~(yapc[OW-Gu`bX^;7<%d~<I%hd }1<w]4>+UXF9,' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
